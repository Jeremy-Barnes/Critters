package com.critters.breakout.graphics;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class Render {
	public static ShapeRenderer sr = new ShapeRenderer();
}
