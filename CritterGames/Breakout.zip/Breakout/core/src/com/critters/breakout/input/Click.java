package com.critters.breakout.input;

public class Click{
	public int x;
	public int y;
	public int button;
	
	public Click(int x, int y, int button){
		this.x = x;
		this.y = y;
		this.button = button;
	}
}
