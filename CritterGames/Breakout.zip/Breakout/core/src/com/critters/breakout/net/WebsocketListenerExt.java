package com.critters.breakout.net;

public interface WebsocketListenerExt
extends WebsocketListener {
    void onError();
}
